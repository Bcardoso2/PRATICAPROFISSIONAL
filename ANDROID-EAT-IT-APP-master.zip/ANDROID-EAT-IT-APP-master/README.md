# Android EAT IT
tested on API 28, nexus5X

 ● Uses Firebase to store data for restraunt

 ● Provides sign in/sign up function, menu and food list loading, orders management
process, and notifications for all the users

 ● Multi-threading manipulation
