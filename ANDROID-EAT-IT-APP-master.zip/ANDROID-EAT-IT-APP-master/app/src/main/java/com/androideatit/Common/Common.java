package com.androideatit.Common;

import com.androideatit.Model.User;

/**
 * Created by 123456 on 2017/11/17.
 */

public class Common {
    public static User currentUser;
    public static final String DELETE = "Delete";
}
